import React from 'react';

export const NoMatch = () => (
  <div>
    <h2>No Match</h2>
  </div>
)
