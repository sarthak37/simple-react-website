import React from 'react'


const  Dooter = () => {
    return (
        <>
        <footer className="bg-light text-center">
        <p> Sarthak Vit vellore    </p>
        </footer>
        </>

    )
}
